package SIDBICrypto.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
// --- <<IS-END-IMPORTS>> ---

public final class inboundRequest

{
	// ---( internal utility methods )---

	final static inboundRequest _instance = new inboundRequest();

	static inboundRequest _newInstance() { return new inboundRequest(); }

	static inboundRequest _cast(Object o) { return (inboundRequest)o; }

	// ---( server methods )---




	public static final void decrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required encryptedText
		// [o] field:0:required plainText
		// [o] field:0:optional errorMsg
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	encryptedText = IDataUtil.getString( pipelineCursor, "encryptedText" );
		pipelineCursor.destroy();
		
		String decryptedString=null;
		String errorMsg=null;
		
		try {
		    decryptedString = decrypt(encryptedText,idbiPrivateKey);
		} catch (NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
		} catch (InvalidKeyException e) {
			errorMsg=e.getMessage();
		} catch (IllegalBlockSizeException e) {
			errorMsg=e.getMessage();
		} catch (BadPaddingException e) {
			errorMsg=e.getMessage();
		} catch (NoSuchPaddingException e) {
			errorMsg=e.getMessage();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "plainText", decryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void encrypt_ (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encrypt_)>> ---
		// @sigtype java 3.5
		// [i] field:0:required plainText
		// [o] field:0:required encryptedText
		// [o] object:0:required byteArrEncryptResp
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	plainText = IDataUtil.getString( pipelineCursor, "plainText" );
		pipelineCursor.destroy();
		
		String encryptedString=null;
		String errorMsg=null;
		
		try {
			encryptedString = Base64.getEncoder().encodeToString(encrypt(plainText,idbiPublicKey));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedText", encryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor_1, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static String sidbiPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxMGvRjrB2ui0f+/sMmfVHPWhXloyzUybnlFUjqOtnDYXEAAqZGP9y5v3kC566CDnK/zZ/mZfwouZ8RS/+UWsqPX689zMl3PkeGZSGXmt7QvOdNCPp8038bXI7r8Wo+rurLqzXyIw5jIvRNw1gGh8Nu9QRaNZ/AM/yaKExWrKhMyWQHIzO6YPp0xx0cugTkJpZ3UmNzlLZ3dcLlhoToyJZix/VuJ7Ek5kjFs80QFJ+oZ2z4t4N0ehKeR5KFsWXnmRommvwMpV7AVo/CvQhtcVravrupWRKNaUJkmuhWPXOecLEDPyImAajk0qCIWE/CfqAeWjMZehthDogH7bLQrgvQIDAQAB";
	private static String sidbiPrivateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDEwa9GOsHa6LR/7+wyZ9Uc9aFeWjLNTJueUVSOo62cNhcQACpkY/3Lm/eQLnroIOcr/Nn+Zl/Ci5nxFL/5Rayo9frz3MyXc+R4ZlIZea3tC8500I+nzTfxtcjuvxaj6u6surNfIjDmMi9E3DWAaHw271BFo1n8Az/JooTFasqEzJZAcjM7pg+nTHHRy6BOQmlndSY3OUtnd1wuWGhOjIlmLH9W4nsSTmSMWzzRAUn6hnbPi3g3R6Ep5HkoWxZeeZGiaa/AylXsBWj8K9CG1xWtq+u6lZEo1pQmSa6FY9c55wsQM/IiYBqOTSoIhYT8J+oB5aMxl6G2EOiAftstCuC9AgMBAAECggEBAKfgDdlhFrfdpuwl3CShvQ6pcVacpQ3PmFN7Vycg9mb7K7BGQ+VF/2xzFcYaMlnOgQ9h/Ol3larbC6zLpIRd81RyE/1v3cw3YK9ttgzwafqAAVZgAMIOcfY0wU0bE4kmUSBlZ9f6xzgRh408ShXWkG0awSW5m3RPnWQ/2wLJ/CNTII2JpZjeuO1a4NRobKrgA6HdEaQmlyiHke77ZyzkM8vcN/qeF/yziB9qDJ8Bf1PduZzccBdSotxRbSTBnBXsCaWC4cSmWz16eXyZrflRruUkJBiu2HEBrhry9lK1VtWQrS2H+j/yVk6TDM1K8mEVWfz+vjbDexVtOz2mu53N+00CgYEA58VLX07jJl/I2Pc2mL1dLygKti/PxLqnu0dE8uVwfJj77i1qcFikpNioewx6/ygYtDNX+Lt/6mjuaAr1CFJypNf1RV8s4eAxZx1W74Ski/Jol4Zo9JOPz2kJiPN52MdC4sw1nZoslDrFD4Hc8kBFCsEWMygXHJsm4979BnWfKqMCgYEA2VNVguIt/fVzUOyYpDQiEwImx0i82SDNJR+et9D0mdjLoJdgtWNl4wOS1mIUJY7otLjE3G+j1DlTYeo3IP+UDOZhIqptKIGlLUo1Tqb5NpUwvq9Ji58a9YWWnT76BjxdOmrSEtgbUrdsDRnixwtiMR+wKuBU4GP8ThRoHlKS3R8CgYA98tkTj3Vdc2quu10HdE3s5cn/KkZhcfaVMxZ1yefIFef4oID7qGXRfeuCgDJ78s6vk62m2Q72q7dVbeBSqh7keqifMzI+6Xqq8gejm5OTqGZWYeG5xZtBt/SJe3KNA62YCzcleekCcbbsTyysP4t0tWlmoQeUaM/7RkXhLR0u+wKBgDbZ5qJDLfKEKdfJ73i6Q8NibqErxaZTthNhmLCyR5ow8qwUqO7/KG8UrtH3LTiRikBaxi0Q7FubIGV9NO7aMubSmr+iHiz0E9mLekrgr9PL8eKe4UQhIy/GyM3lYDuErs8YuO7SporJCrd/yhIM2HqnkdIwjpuYAM1AL0s/8htnAoGAJ7kBVonKe5vTzUr8zleD7OR+NdtEed9TFBQW/YX+tZVoiNgsGItzkIHT85K8+nbrRLSdHmho1uqUkpT2smTk2JCUwZqBivmWhcx2XqHmBgz7R+F0hWdN/CyzN3qKXX0yq4brlvAyQ+I0OUVhiVr+BQBT3qwipA71s2nI0XYpy/0=";
	private static String idbiPublicKey = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArOQafItPxi3aOzFWPGEi8KYd5xnRyHPxetIjDgyKBxV+vy04L2kMa9TwgXcMLgVgyjTpBKwWzgntdtfT3VizBTqAJ2PkiZ29esbEennvdaYw4xiBJDjYPSttgO2UaLrgm17meHklLqrGX1MDx+t2iY/15I9ii8UGamsWgE/hxyXlqx3v8CNdhQgB1DElLJ2tYbR+zZpay2/eKjbhfrxgKGFnM/7jL7/M57kxMRbAx51cdLMD5gs7XCqQQGCzMBfLcRwHtBcopI1awmQVfUW/hEHDBpIjBe2awv8dgXqtoWrQC9JzHIZ5FMzJ39Fn+/HOrSurc3FvXMGq/rBzKp6stfstoimKgOj3mUTIrhJfGdLj3XLRqglUZcWtLA1LMlbx5BTxPEXp4ASUchVc/BtlRTjNde4UdeDgcYGzLTBKyCu6iSKaml+CQzUypRUVKw7KpAktS4+9GNlesjNmRpVlsNpYdRzo8KREvmAL5uhtBIMjeojpFrdKt9meNFuMd5WGn3aNnoN2Yu+mmFkP5IwUzuiRjcUZsJWRwMsqPdg84EG6vniAa97wgvuI4CBpRPNVHS7+xHtECEBuo0bi5NsBthg/ntQzZp92BilrYPDqoiNzi181UGWBRvA8aR0ugT6AhpFzoAk8AmMVZ/CdcuCszt4AgmNXqaf2bWVlBOlF7PUCAwEAAQ==";
	private static String idbiPrivateKey = "MIIJKAIBAAKCAgEArOQafItPxi3aOzFWPGEi8KYd5xnRyHPxetIjDgyKBxV+vy04L2kMa9TwgXcMLgVgyjTpBKwWzgntdtfT3VizBTqAJ2PkiZ29esbEennvdaYw4xiBJDjYPSttgO2UaLrgm17meHklLqrGX1MDx+t2iY/15I9ii8UGamsWgE/hxyXlqx3v8CNdhQgB1DElLJ2tYbR+zZpay2/eKjbhfrxgKGFnM/7jL7/M57kxMRbAx51cdLMD5gs7XCqQQGCzMBfLcRwHtBcopI1awmQVfUW/hEHDBpIjBe2awv8dgXqtoWrQC9JzHIZ5FMzJ39Fn+/HOrSurc3FvXMGq/rBzKp6stfstoimKgOj3mUTIrhJfGdLj3XLRqglUZcWtLA1LMlbx5BTxPEXp4ASUchVc/BtlRTjNde4UdeDgcYGzLTBKyCu6iSKaml+CQzUypRUVKw7KpAktS4+9GNlesjNmRpVlsNpYdRzo8KREvmAL5uhtBIMjeojpFrdKt9meNFuMd5WGn3aNnoN2Yu+mmFkP5IwUzuiRjcUZsJWRwMsqPdg84EG6vniAa97wgvuI4CBpRPNVHS7+xHtECEBuo0bi5NsBthg/ntQzZp92BilrYPDqoiNzi181UGWBRvA8aR0ugT6AhpFzoAk8AmMVZ/CdcuCszt4AgmNXqaf2bWVlBOlF7PUCAwEAAQKCAgBZTna0EM5DY5oP63tNMyv2PQjDQJ4RunppZDTBZA7EfAD9xeD49H17EgKuDY2YFCUcLlqTlEUvZwdn1TLWaqQGtmJOdpYt0/J1gkkpruTX0+H63MSQrmBcsJse9xorQyUUfN/2KTXgtkxEH0Cbu3B+vINa7goMgti+jdSQsTLCSTwquQsg81OyjSFMt5opQsW166N4lxwBbCbJjZHLgoj1MuM5g5ddKekxZYMYhVVNh2ajzXjdEr417LKY3pqQ5CmtoroD99aBsZbJRSOokyfLrKCOO1ymCkdgJKHcKT+ZWvBeuvXFLV1MNkCtQaFCDnUhFKa6ukS5GD041HKY+F/jw1sPIkQHtmF/mU3/22u/UJuF0ER1MTRQ7QOUQJNT1TSBE5Uc33nH/WUUT1+FP6x8K8/SPoNADxzS+WaqWWV93zSZUc4Kep4DbmiomRUesAk/9uscba3ohrL0jqTwEfAWTC0qUIfm4XiBfukDie1954zhRS8ljFUozRVAIw+s82Dfwl+fMmEYGNm5iiwWC3N4xNg1iRUEAii7AyHwMqYFgjPCndg9++aslphk5n+FcdDRew+W08tnD9B7664j6O81f0F9TKXFfBlQJ0KW4cd73R0UwY6nxg0P47W9BapBG1Cc9+ZTGhiZnEdi4KPXt1LcMGR2Ar210FVdrakxSpjrQQKCAQEA3Wr/hb7BkWIqgJzoPxJ+d9lkcGy1HDBl79EvWo+dmsYTKNFwfUfg3KQwhxHalFYOaouIesZwlfw4TXvAHXOCX3c3hlISQA370QPxAQqqexiPWJeY+/HQZMV9h6nM0U9ZO4/UWTpvBFuUvQjWv3pe7AW8NS9bJiqG/RekOK9hdA7n83wPXjVnMcVNCenbQpJBdzf9dcyPDfBTMpNWHTwQisZe+CMKREzPMAmqjo/MTjitgIJc86tcAi/0Zvri31duLtq9f3IL5kNLua+dw7ze0DYcu7T7TOyysAznavd0XKGR/Vb06g+qb8wOxF3ldnIGyoEmrIBOSy2w3mmpK9q6JQKCAQEAx+TXs19h8m5vX2yQTDCoyILdpb+6knWlfQfvoTMLSDvkGWWorQyBZZeCaaBIfG/KeezK/MPXbuVEMKRxe1m1mx7u+4CtoD2gjY3Vrb4zzDUtcHUf/MqX5AuO2CzMO09tRMDZtZeBwgkgv4ZaX/oghQOeJGnwea94FkrMTEZvHwbCt5eT/DoqkwMGmcRHfx0km112f4NbsEtDoJz9fWKt0dIaW0Qh98T23mb93Eml4vHGsx0KHqACV/l96KPahA/d8qxBNcH3Rm/pT0OCOvYzBzAzES/BcrbhmvD0dKRsPHWiwp/Ra7BZk71ERV8m2U4XXtlWMy30NRjJ70eIJW0mkQKCAQEArNoM5IJIZpC2EXVssWBkrnddu46BzKHT0mYBi7c2GE+tQV5PbN4iIt1irO85LjgIRRDs2Lv1xIEECykij1tPWeudwxRq/uprvX5QNLn44OQJc+XVHkpmn2S1XKUoKfbB+IeOBKJjbIl6EiDGVPDZDXRkuzhe9eqZOxersjzn3UyNsz0UWj1idC5MuAKCkvPOe52QFtg8jWsh6AexYF01pMC7/waLy0oTLLM/HNARdLc2a25Z1jfeOi7po0MUvbppX9aPvOBxfa7nfOwmQ1o8r1qvD7J3xFO8I0fPmWfYxT+00ouB4v+b1G7+0DllGxRlTM2KPXxkorfmrZra4Et+qQKCAQB2ousiGkoXiFOxXs2FapvB5WmHJfOlWQ2O11bxZUoc5O7L4/noOrPRh8puxiI/OFoDYvZWbiU+O/PsqqxveR6/oexUeFqT7/+KA9P9+hTj7eu6AsmpTtQ3FGUDCBNuYAWJ+Ks9i14Hu0MkaKjaraj/SNZi5j1C+1Faaao22ta4o1qNe/joid0aw4D3YfbNCo7fZukdZOjWCNVqTcJk2FwxW3EpGZbPZqbd+GJSi6NYvgYf5+xJoM3DSN/hYt4d4wznKjTJowUPWPwvfvGb7OL8MS8d1CoL216qhrePQsa6W1buC8xPDascdAhA4+g6sI5OTM9MMMnveXbf/KRhEhcBAoIBADKV+HNJ4xDo0BHCb5jaf5ZebTK/NwL3zk1jKilTYowmKv2D31Z8/Ba3Y/VP0F8rtmUegurIDK/EC7BWUDPiCZ+cpjrtde3AN1PbBSFbjFKKvpU5/wWlRy5432lI8o/BAWfpNsizoagKmEVSekCQx87dwrOyTmVgG4WrBOG+fl8aFL4MDiSrspt/5DtpJi1eT++9mioruxqpEnxDhGeRYr+S2MOeewIHledlm/esj5WLROazEsht8PaOlmyVI4RhVA/yOcXrnk3cNUouZcylfOKOProPxmWUQIXAuAbj2zpfEbxI3xlJiNxNPKB0JbzU0NAkeMM83FzHExp4TDNMDRM=";
	
	//Extracting Public Key
	public static PublicKey getPublicKey(String base64PublicKey){
	    PublicKey publicKey = null;
	    try{
	        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        publicKey = keyFactory.generatePublic(keySpec);
	        return publicKey;
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return publicKey;
	}
	
	//Extracting Private Key
	public static PrivateKey getPrivateKey(String base64PrivateKey){
	    PrivateKey privateKey = null;
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
	    KeyFactory keyFactory = null;
	    try {
	        keyFactory = KeyFactory.getInstance("RSA");
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    try {
	        privateKey = keyFactory.generatePrivate(keySpec);
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return privateKey;
	}
	
	//Encrypting SIDBI Response
	public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
	    return cipher.doFinal(data.getBytes());
	}
	
	//Decrypting SIDBI Request
	public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.DECRYPT_MODE, privateKey);
	    return new String(cipher.doFinal(data));
	}
	
	public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
	    return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
	}
	// --- <<IS-END-SHARED>> ---
}

