package SIDBICrypto.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterOutputStream;
// --- <<IS-END-IMPORTS>> ---

public final class outboundResponse

{
	// ---( internal utility methods )---

	final static outboundResponse _instance = new outboundResponse();

	static outboundResponse _newInstance() { return new outboundResponse(); }

	static outboundResponse _cast(Object o) { return (outboundResponse)o; }

	// ---( server methods )---




	public static final void decrypt_ (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decrypt_)>> ---
		// @sigtype java 3.5
		// [i] field:0:required encryptedText
		// [o] field:0:required plainText
		// [o] field:0:optional errorMsg
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	encryptedText = IDataUtil.getString( pipelineCursor, "encryptedText" );
		pipelineCursor.destroy();
		
		String decryptedString=null;
		String errorMsg=null;
		
		try {
		    decryptedString = decrypt(encryptedText,sidbiPrivateKey);
		} catch (NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
		} catch (InvalidKeyException e) {
			errorMsg=e.getMessage();
		} catch (IllegalBlockSizeException e) {
			errorMsg=e.getMessage();
		} catch (BadPaddingException e) {
			errorMsg=e.getMessage();
		} catch (NoSuchPaddingException e) {
			errorMsg=e.getMessage();
		} catch (IOException e) {
			errorMsg=e.getMessage();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "plainText", decryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void encrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required plainText
		// [o] field:0:required encryptedText
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	plainText = IDataUtil.getString( pipelineCursor, "plainText" );
		pipelineCursor.destroy();
		
		String encryptedString=null;
		String errorMsg=null;
		
		try {
			encryptedString = Base64.getEncoder().encodeToString(encrypt(compressAndReturnB64(plainText), sidbiPublicKey));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException  | IOException e) {
			errorMsg=e.getMessage();
		} 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedText", encryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static String sidbiPublicKey ="MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAl1D9nzyl0yamZcOyStNFnHI5hG7OPpR47WDQFSlTLqFC6O0IYFUYEbeKegFuQm4cGDl577c5lYDhWE2UGTKjLklH/zD+oTZvLTUMTU+zeXiYVKxA3AdxSDjpl1XsUGaH6nJlCqlHl6jmkS8mL+xTWYCS3uXrfrMSWvduN8BH0aKxZbyFeRZlwLrDX+1HhN7WQV0nXvnhrO584s5Ji2Tcos/jaQrM13iwXAK1hjM13G2S+qTEaTqGOWxXwJV8wUOmVFONigtLsk2f2s8MnMV6HhpbzIBPy6XmI5RGQ2aBhFcOmvvpZ9Y9WcikLvXrHCamdT7VkKxbrjxUFpDS4EymVqfrKjG6X7o06JTsNmXexuClJgQHDoVPfy/igSDrZBqtzRHeqkyOhmw9iknntNqNBBCfloOavb2eA2CJegN4AW+xZHVUYVbf40tAbHXWyykGPgKtp7JmxRXHW/DdvUOzi7A2+syDjmVSUAKnUuuNAHNk9mGXl++HtkIfzs61gIXVIzImcckrFfLzv5uyAh5jFsvPnAoOrF+MYogRdD5K7Q7EdyBAlWnSTbxMZYqJdgokG5u69hAqnyGIIwsFoTYc2rqyYjWAbDPcveDyXIGPvW9b7R8rzOPllF6idwXs+56O6ENBPIrIBQS4HKi0sAj1YBPVYOHMoOyO7eFfMrcPWaECAwEAAQ==";
			//"MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA2NYgA18OgnVnjFsZcI1/N65FJN58pSBmyFlYWomNzEvRboQOViohZmkVRPVpFV9sB6aL3ZXf6uRGxDW/Jki5DDuTsxx8OAUIxR4g+LohFR/OW5bu2oHUxed5JoDkrtf/15R4ILkN89B3wErkWUkzIxpbEvlk8++/DGuuIjcJBQTbmPbC5znDnPDt+h5veL981G4BGobUC0iy2wl2aRkv7M0p3oFTQ0srAKDXOvHyQs2Lm+q1bho+B8SI/ft5JH039BOdXO3LKwDf6EW0v652XP3MkAmFtdzzJ0+WcS9Dzu4IdW/BsDKR2/aQgQidU2bEr9ZCDDCICCF7g1cHqLQe+y3CzHS4ZhDcF3q5LKqwEkey333tyWj9aUZlgb/6NPyjzF6qX3uj9S6IsE8oU1QraDpSks0HrLe4egQfUsZHTJYRBgVy3L6F9dsEmoXwuxKTheJrhFlQ8YMW0W5VYLCd0YvxkVJtuprq2LJP4W3i8xfefaJkAjdAxV+kvDFiu0mAxr0wxOwIFa6v/+gfjP4BWgFPq9uxS5PZvWe5obHBwd31aWI2ZkyHZ+rQjn8/hORrORmby1qoNDFFhsYIMRrkYfbrfxaoOFIDVKxlTAXbKGcAW+t54auor0R6tPy2WT6RBjKnzmYpgNHwF1dFviwoMJRIy5TiUGpXe5xA0/RkHd0CAwEAAQ==";
			//"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxMGvRjrB2ui0f+/sMmfVHPWhXloyzUybnlFUjqOtnDYXEAAqZGP9y5v3kC566CDnK/zZ/mZfwouZ8RS/+UWsqPX689zMl3PkeGZSGXmt7QvOdNCPp8038bXI7r8Wo+rurLqzXyIw5jIvRNw1gGh8Nu9QRaNZ/AM/yaKExWrKhMyWQHIzO6YPp0xx0cugTkJpZ3UmNzlLZ3dcLlhoToyJZix/VuJ7Ek5kjFs80QFJ+oZ2z4t4N0ehKeR5KFsWXnmRommvwMpV7AVo/CvQhtcVravrupWRKNaUJkmuhWPXOecLEDPyImAajk0qCIWE/CfqAeWjMZehthDogH7bLQrgvQIDAQAB"; 
	private static String sidbiPrivateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDEwa9GOsHa6LR/7+wyZ9Uc9aFeWjLNTJueUVSOo62cNhcQACpkY/3Lm/eQLnroIOcr/Nn+Zl/Ci5nxFL/5Rayo9frz3MyXc+R4ZlIZea3tC8500I+nzTfxtcjuvxaj6u6surNfIjDmMi9E3DWAaHw271BFo1n8Az/JooTFasqEzJZAcjM7pg+nTHHRy6BOQmlndSY3OUtnd1wuWGhOjIlmLH9W4nsSTmSMWzzRAUn6hnbPi3g3R6Ep5HkoWxZeeZGiaa/AylXsBWj8K9CG1xWtq+u6lZEo1pQmSa6FY9c55wsQM/IiYBqOTSoIhYT8J+oB5aMxl6G2EOiAftstCuC9AgMBAAECggEBAKfgDdlhFrfdpuwl3CShvQ6pcVacpQ3PmFN7Vycg9mb7K7BGQ+VF/2xzFcYaMlnOgQ9h/Ol3larbC6zLpIRd81RyE/1v3cw3YK9ttgzwafqAAVZgAMIOcfY0wU0bE4kmUSBlZ9f6xzgRh408ShXWkG0awSW5m3RPnWQ/2wLJ/CNTII2JpZjeuO1a4NRobKrgA6HdEaQmlyiHke77ZyzkM8vcN/qeF/yziB9qDJ8Bf1PduZzccBdSotxRbSTBnBXsCaWC4cSmWz16eXyZrflRruUkJBiu2HEBrhry9lK1VtWQrS2H+j/yVk6TDM1K8mEVWfz+vjbDexVtOz2mu53N+00CgYEA58VLX07jJl/I2Pc2mL1dLygKti/PxLqnu0dE8uVwfJj77i1qcFikpNioewx6/ygYtDNX+Lt/6mjuaAr1CFJypNf1RV8s4eAxZx1W74Ski/Jol4Zo9JOPz2kJiPN52MdC4sw1nZoslDrFD4Hc8kBFCsEWMygXHJsm4979BnWfKqMCgYEA2VNVguIt/fVzUOyYpDQiEwImx0i82SDNJR+et9D0mdjLoJdgtWNl4wOS1mIUJY7otLjE3G+j1DlTYeo3IP+UDOZhIqptKIGlLUo1Tqb5NpUwvq9Ji58a9YWWnT76BjxdOmrSEtgbUrdsDRnixwtiMR+wKuBU4GP8ThRoHlKS3R8CgYA98tkTj3Vdc2quu10HdE3s5cn/KkZhcfaVMxZ1yefIFef4oID7qGXRfeuCgDJ78s6vk62m2Q72q7dVbeBSqh7keqifMzI+6Xqq8gejm5OTqGZWYeG5xZtBt/SJe3KNA62YCzcleekCcbbsTyysP4t0tWlmoQeUaM/7RkXhLR0u+wKBgDbZ5qJDLfKEKdfJ73i6Q8NibqErxaZTthNhmLCyR5ow8qwUqO7/KG8UrtH3LTiRikBaxi0Q7FubIGV9NO7aMubSmr+iHiz0E9mLekrgr9PL8eKe4UQhIy/GyM3lYDuErs8YuO7SporJCrd/yhIM2HqnkdIwjpuYAM1AL0s/8htnAoGAJ7kBVonKe5vTzUr8zleD7OR+NdtEed9TFBQW/YX+tZVoiNgsGItzkIHT85K8+nbrRLSdHmho1uqUkpT2smTk2JCUwZqBivmWhcx2XqHmBgz7R+F0hWdN/CyzN3qKXX0yq4brlvAyQ+I0OUVhiVr+BQBT3qwipA71s2nI0XYpy/0=";
	private static String idbiPublicKey = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3MsAxF5yrTBHb67s4q6Qq+IN16nAgJntvpqO+LM4ntmvnnAnGmsNvCoMWHOHUT/VaKgJlI/pfMK4OMwpTDFTQbh9pA0ilh1gMGFHw8l5XdG7Z3D4Rm4SvePs9csVCcXj7w1QcrPL2tBqZIWmeV25lfBNSYfmTHH7OndkUyO+oaUw9i1cT6GLQ7hd7481qzUwhEoNAR1qIrKMK5W73r56PK6UUgrmGYyiULhgLcQn0kMszBjH/Nn/DeDWAYuO+zb/sK2+YyvztxrK7f/QdWkeTU4B22FaCeh4POJu6upy7vKDN/S0VeZ0WASFYSzdqU4PICkl8J4BH9V7HbKG2ORog7EHTDTtw1ucTS79bVULi7J71Ma4ak2ZO0veeyOTlSiDctNx/Bn8wBhbypiZJroIJ1D2ivgJtD64EqiWyi7UeMkSJ3RG233Z+K68697Uu2ppWFnmJZz8w9cEXsSBHjoH0ZreZhNZMK5KrGuqWnT5+gqZ4miXYNbcavqN54zm9oQCCFcjf1HHkZ2ROdfWdFgXEuMiAtd4ws1m9ht7fv5W/cKmW6CHbrgQEO15P+F8BSr7bVO65PapljvVeDiSpC4LwO1AW0LnzWgEjXKd0zgNx2Ss+H0c4PB2sS/KtIkNPAODTvi4Rv0qwSFbDQdsamXAXshbMZShYY3ACLtitvovMqsCAwEAAQ==";
	private static String idbiPrivateKey = "MIIJRAIBADANBgkqhkiG9w0BAQEFAASCCS4wggkqAgEAAoICAQDcywDEXnKtMEdvruzirpCr4g3XqcCAme2+mo74szie2a+ecCcaaw28KgxYc4dRP9VoqAmUj+l8wrg4zClMMVNBuH2kDSKWHWAwYUfDyXld0btncPhGbhK94+z1yxUJxePvDVBys8va0GpkhaZ5XbmV8E1Jh+ZMcfs6d2RTI76hpTD2LVxPoYtDuF3vjzWrNTCESg0BHWoisowrlbvevno8rpRSCuYZjKJQuGAtxCfSQyzMGMf82f8N4NYBi477Nv+wrb5jK/O3Gsrt/9B1aR5NTgHbYVoJ6Hg84m7q6nLu8oM39LRV5nRYBIVhLN2pTg8gKSXwngEf1XsdsobY5GiDsQdMNO3DW5xNLv1tVQuLsnvUxrhqTZk7S957I5OVKINy03H8GfzAGFvKmJkmuggnUPaK+Am0PrgSqJbKLtR4yRIndEbbfdn4rrzr3tS7amlYWeYlnPzD1wRexIEeOgfRmt5mE1kwrkqsa6padPn6CpniaJdg1txq+o3njOb2hAIIVyN/UceRnZE519Z0WBcS4yIC13jCzWb2G3t+/lb9wqZboIduuBAQ7Xk/4XwFKvttU7rk9qmWO9V4OJKkLgvA7UBbQufNaASNcp3TOA3HZKz4fRzg8HaxL8q0iQ08A4NO+LhG/SrBIVsNB2xqZcBeyFsxlKFhjcAIu2K2+i8yqwIDAQABAoICAQCaBQ6q7UvH3pbmpLrgwm9vR8jqOaNs0nQTc1Pqz3Le9PHab1gHyMgTC64DAcxSdFoVoKrWNLHm8xp5nInuebYfcWhLyVHoL+PKvAHI5UHBna3CUf8PeneeeWHycFFjuOTw/HOzIBNDuAGPz9+6aBQvMSto8OFJUHW1alXU3Wl873RBNpFfh0xT2EfG9jq1DOykS9fYgEFqpOy89r3Qe0VgEVSsCqhLCFyuPH/zTROOTIfydBMGIrgWYVJIT6dVPR+OixT1r1Ja19jZv4sWbFbUDGelNrsNkFpX9ojzXMsCPrAkl5I5HgLo53Z3vEmAclCA2dN6j24vW8d/huskX+k7MJMb45ErtYOgqvX/3gY/UVi2FlazoVg6+CCj1LhKPRCfvhH8Gcsk/BiYxATWRqxW5xVPBnBevx0FR61Po6K+FyXSusjtIdLYVYi+ONbxV8z+KzJehX+XbqIohbQNqGyk4kMej+k2pgNteuPqTfFeCltdegB/GdltbxJDVSsZgOTSvENE93O0GnrJTI9Bafl4zGVg8Ruim7NiFLHLCEl8jaAlM6yWCNj0vyhnUJRRI7l5skwIFehFhjBvrXBas9RHHlXo3O0vIOX0QfhrHLzz1dDIpC4Fj1UgOzvvM61pq6XMs42NcWVl69Yr774DD39/ldmtpdChvX09WAft0UntaQKCAQEA9uYvq/zp8IkpJ+hPhn1v853oifFDeMNYgLzhhFV9yS7w3oGU/CJykXJfuK3BTJUVJOqjqTxBkZb15rfqt5HUCPEvp9jlVTnT6PsLhaRsNKosV8BAYbVGmsf/oLHWoLWC88aH0PsHfKtJLAI7Zm7Wtl5FSWwJeSXfX9Rss+keJXF6TLiATFupK5yYPm88Knd7QhQkVp2NGFStUsPqlqcZF8bYofkyoScWbJz6DGZalOFHMqX1FrnqEJJuohPZ3ddZnXmPqxjwlVt63lOwQ7chuJqMTYjB4jaXypqXPP1YHZLskxNLcjnETQYoRbRYdrjkajFIU8RoMuLoZ0waCTiydwKCAQEA5O54mGPU0S1eWbrW7Rbmlxef/Ii860S/EjoQtUmqgdvB6vwBHUNupz2y58XA6ur05nVPovrpHiSkvcePSkU83EjN/82FNY4ph7ONxE82hFBWffQjbBXXyrdPvGiaJvJVMwGqn+IuX0x1npAyzVIG70YxRSV6VBWTYSlhoUFzqj4KS/1y1zWVHv3VLnJKRmntJeIFmPWqCdyUQYT6H1689xeD0vl+DRgKWBxemYuhafIAqFOUDq4kjyvd5PUnv5ItBt/THq/ePTi+DA6eAZqNFdcyrW7Z9Cs8vnOJn/bL0b0FsrvRbB23Spt2PI8o9OlNCVxiPhy3sUt1HIyfDRX6bQKCAQEA7493b/RtdONRGJSzHPZ2+rUb3URISFOaewdJ9eIRs3QlaG/pBB/UdEW6lPGa3djFdFVqyRlbMY19OQj46HbJeoeyyrSMCH6cm7GCg4B/MTZw4g/7KBMA18v4v43uh263Cht2ypHXuOJllBryUbh4AulDZzM5md/idhQiCQrHImOR3AElE3HYmiVOHz5E7ZuS8BGlFJm4PoRizCymYNjvYv+gUMD/nBfWDTre78scVtqi/4TBYvSvJLdAO2jxeuup2z8I5GXFgdYKSNCA9aMqR/lE6zInlXuNGpuW5SmYJtHZU/djvAhK7MVtq/yJ3WAW2ObKm+S1ibJa92eC17G4jwKCAQA355RDgn2B51ZXCy1ZEHKXCwninXGk8lDGnq9d1fNxarzcKVYMU18+L+70cnI968qKTLN51VQALGqefZEcTfQixxSnFwUkoua5YLuJ6N4jSYsVjvzndB4SPtmV5OVgBWWQ4yNLj+xLEVzXr9b4FMPkwntdq11IE0y+OWDCBD2+oQ/aprXYoBkeTFY21WoV7+AdlChRxgwUBG2f4l1CM9xparCiYJLLl8dO5P6k+Fgeix5l/KL3Qsdivw+czdE7EvMz7oybvc7DnIusXhVvxtIVN0wE1kEbQ0O+LnC5Q4daXJJ7pynpAQi1i2lAOKWDyUUquAi1qkWhYg/jPOPKSkexAoIBAQDMolcAtSqD924GBcltIFzMW0uocSWa/PDe0cXjGMG8CanW++V2oWGnx/zYSPVR87qVZuTe3NUq0SBFDt0AvNvfmHtTIE/eURfBioy5kS6IiE2EBC6DCNbTLCHoPPmHvQSO91NbqA6KH8aTce9kuilrPO5og3lIBSnwKKjJVVbGbAzvG6VoytUs/WgWpkCT3UseIo8sBpk80AfomdiJ4smGEJUg2/E3C7h7ZM3soQj+EAi/wOrfR/mgInJd4ZJtDCse7XiOV0hiiCo/gT3V200xFRDRCfKWYg1Bo6UyqLxyzhng+KiGHm/Q4sA8qRZMRYXWLnVBLVJN2vIDy+4LZINL";
	//private static String idbiPublicKey = "MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEArOQafItPxi3aOzFWPGEi8KYd5xnRyHPxetIjDgyKBxV+vy04L2kMa9TwgXcMLgVgyjTpBKwWzgntdtfT3VizBTqAJ2PkiZ29esbEennvdaYw4xiBJDjYPSttgO2UaLrgm17meHklLqrGX1MDx+t2iY/15I9ii8UGamsWgE/hxyXlqx3v8CNdhQgB1DElLJ2tYbR+zZpay2/eKjbhfrxgKGFnM/7jL7/M57kxMRbAx51cdLMD5gs7XCqQQGCzMBfLcRwHtBcopI1awmQVfUW/hEHDBpIjBe2awv8dgXqtoWrQC9JzHIZ5FMzJ39Fn+/HOrSurc3FvXMGq/rBzKp6stfstoimKgOj3mUTIrhJfGdLj3XLRqglUZcWtLA1LMlbx5BTxPEXp4ASUchVc/BtlRTjNde4UdeDgcYGzLTBKyCu6iSKaml+CQzUypRUVKw7KpAktS4+9GNlesjNmRpVlsNpYdRzo8KREvmAL5uhtBIMjeojpFrdKt9meNFuMd5WGn3aNnoN2Yu+mmFkP5IwUzuiRjcUZsJWRwMsqPdg84EG6vniAa97wgvuI4CBpRPNVHS7+xHtECEBuo0bi5NsBthg/ntQzZp92BilrYPDqoiNzi181UGWBRvA8aR0ugT6AhpFzoAk8AmMVZ/CdcuCszt4AgmNXqaf2bWVlBOlF7PUCAwEAAQ==";
	//private static String idbiPrivateKey = "MIIJKAIBAAKCAgEArOQafItPxi3aOzFWPGEi8KYd5xnRyHPxetIjDgyKBxV+vy04L2kMa9TwgXcMLgVgyjTpBKwWzgntdtfT3VizBTqAJ2PkiZ29esbEennvdaYw4xiBJDjYPSttgO2UaLrgm17meHklLqrGX1MDx+t2iY/15I9ii8UGamsWgE/hxyXlqx3v8CNdhQgB1DElLJ2tYbR+zZpay2/eKjbhfrxgKGFnM/7jL7/M57kxMRbAx51cdLMD5gs7XCqQQGCzMBfLcRwHtBcopI1awmQVfUW/hEHDBpIjBe2awv8dgXqtoWrQC9JzHIZ5FMzJ39Fn+/HOrSurc3FvXMGq/rBzKp6stfstoimKgOj3mUTIrhJfGdLj3XLRqglUZcWtLA1LMlbx5BTxPEXp4ASUchVc/BtlRTjNde4UdeDgcYGzLTBKyCu6iSKaml+CQzUypRUVKw7KpAktS4+9GNlesjNmRpVlsNpYdRzo8KREvmAL5uhtBIMjeojpFrdKt9meNFuMd5WGn3aNnoN2Yu+mmFkP5IwUzuiRjcUZsJWRwMsqPdg84EG6vniAa97wgvuI4CBpRPNVHS7+xHtECEBuo0bi5NsBthg/ntQzZp92BilrYPDqoiNzi181UGWBRvA8aR0ugT6AhpFzoAk8AmMVZ/CdcuCszt4AgmNXqaf2bWVlBOlF7PUCAwEAAQKCAgBZTna0EM5DY5oP63tNMyv2PQjDQJ4RunppZDTBZA7EfAD9xeD49H17EgKuDY2YFCUcLlqTlEUvZwdn1TLWaqQGtmJOdpYt0/J1gkkpruTX0+H63MSQrmBcsJse9xorQyUUfN/2KTXgtkxEH0Cbu3B+vINa7goMgti+jdSQsTLCSTwquQsg81OyjSFMt5opQsW166N4lxwBbCbJjZHLgoj1MuM5g5ddKekxZYMYhVVNh2ajzXjdEr417LKY3pqQ5CmtoroD99aBsZbJRSOokyfLrKCOO1ymCkdgJKHcKT+ZWvBeuvXFLV1MNkCtQaFCDnUhFKa6ukS5GD041HKY+F/jw1sPIkQHtmF/mU3/22u/UJuF0ER1MTRQ7QOUQJNT1TSBE5Uc33nH/WUUT1+FP6x8K8/SPoNADxzS+WaqWWV93zSZUc4Kep4DbmiomRUesAk/9uscba3ohrL0jqTwEfAWTC0qUIfm4XiBfukDie1954zhRS8ljFUozRVAIw+s82Dfwl+fMmEYGNm5iiwWC3N4xNg1iRUEAii7AyHwMqYFgjPCndg9++aslphk5n+FcdDRew+W08tnD9B7664j6O81f0F9TKXFfBlQJ0KW4cd73R0UwY6nxg0P47W9BapBG1Cc9+ZTGhiZnEdi4KPXt1LcMGR2Ar210FVdrakxSpjrQQKCAQEA3Wr/hb7BkWIqgJzoPxJ+d9lkcGy1HDBl79EvWo+dmsYTKNFwfUfg3KQwhxHalFYOaouIesZwlfw4TXvAHXOCX3c3hlISQA370QPxAQqqexiPWJeY+/HQZMV9h6nM0U9ZO4/UWTpvBFuUvQjWv3pe7AW8NS9bJiqG/RekOK9hdA7n83wPXjVnMcVNCenbQpJBdzf9dcyPDfBTMpNWHTwQisZe+CMKREzPMAmqjo/MTjitgIJc86tcAi/0Zvri31duLtq9f3IL5kNLua+dw7ze0DYcu7T7TOyysAznavd0XKGR/Vb06g+qb8wOxF3ldnIGyoEmrIBOSy2w3mmpK9q6JQKCAQEAx+TXs19h8m5vX2yQTDCoyILdpb+6knWlfQfvoTMLSDvkGWWorQyBZZeCaaBIfG/KeezK/MPXbuVEMKRxe1m1mx7u+4CtoD2gjY3Vrb4zzDUtcHUf/MqX5AuO2CzMO09tRMDZtZeBwgkgv4ZaX/oghQOeJGnwea94FkrMTEZvHwbCt5eT/DoqkwMGmcRHfx0km112f4NbsEtDoJz9fWKt0dIaW0Qh98T23mb93Eml4vHGsx0KHqACV/l96KPahA/d8qxBNcH3Rm/pT0OCOvYzBzAzES/BcrbhmvD0dKRsPHWiwp/Ra7BZk71ERV8m2U4XXtlWMy30NRjJ70eIJW0mkQKCAQEArNoM5IJIZpC2EXVssWBkrnddu46BzKHT0mYBi7c2GE+tQV5PbN4iIt1irO85LjgIRRDs2Lv1xIEECykij1tPWeudwxRq/uprvX5QNLn44OQJc+XVHkpmn2S1XKUoKfbB+IeOBKJjbIl6EiDGVPDZDXRkuzhe9eqZOxersjzn3UyNsz0UWj1idC5MuAKCkvPOe52QFtg8jWsh6AexYF01pMC7/waLy0oTLLM/HNARdLc2a25Z1jfeOi7po0MUvbppX9aPvOBxfa7nfOwmQ1o8r1qvD7J3xFO8I0fPmWfYxT+00ouB4v+b1G7+0DllGxRlTM2KPXxkorfmrZra4Et+qQKCAQB2ousiGkoXiFOxXs2FapvB5WmHJfOlWQ2O11bxZUoc5O7L4/noOrPRh8puxiI/OFoDYvZWbiU+O/PsqqxveR6/oexUeFqT7/+KA9P9+hTj7eu6AsmpTtQ3FGUDCBNuYAWJ+Ks9i14Hu0MkaKjaraj/SNZi5j1C+1Faaao22ta4o1qNe/joid0aw4D3YfbNCo7fZukdZOjWCNVqTcJk2FwxW3EpGZbPZqbd+GJSi6NYvgYf5+xJoM3DSN/hYt4d4wznKjTJowUPWPwvfvGb7OL8MS8d1CoL216qhrePQsa6W1buC8xPDascdAhA4+g6sI5OTM9MMMnveXbf/KRhEhcBAoIBADKV+HNJ4xDo0BHCb5jaf5ZebTK/NwL3zk1jKilTYowmKv2D31Z8/Ba3Y/VP0F8rtmUegurIDK/EC7BWUDPiCZ+cpjrtde3AN1PbBSFbjFKKvpU5/wWlRy5432lI8o/BAWfpNsizoagKmEVSekCQx87dwrOyTmVgG4WrBOG+fl8aFL4MDiSrspt/5DtpJi1eT++9mioruxqpEnxDhGeRYr+S2MOeewIHledlm/esj5WLROazEsht8PaOlmyVI4RhVA/yOcXrnk3cNUouZcylfOKOProPxmWUQIXAuAbj2zpfEbxI3xlJiNxNPKB0JbzU0NAkeMM83FzHExp4TDNMDRM=";
		
	//Extracting Public Key
	public static PublicKey getPublicKey(String base64PublicKey){
	    PublicKey publicKey = null;
	    try{
	        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        publicKey = keyFactory.generatePublic(keySpec);
	        return publicKey;
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return publicKey;
	}
	
	//Extracting Private Key
	public static PrivateKey getPrivateKey(String base64PrivateKey){
	    PrivateKey privateKey = null;
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
	    KeyFactory keyFactory = null;
	    try {
	        keyFactory = KeyFactory.getInstance("RSA");
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    try {
	        privateKey = keyFactory.generatePrivate(keySpec);
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return privateKey;
	}
	
	//Encrypting SIDBI Response
	public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
	    return cipher.doFinal(data.getBytes());
	}
	
	//Decrypting SIDBI Request
	public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.DECRYPT_MODE, privateKey);
	    return new String(cipher.doFinal(data));
	}
	
	public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, IOException {
	    return decompressB64(decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey)));
	}
	public static byte[] compress(String text) throws IOException {
	    return compress(text.getBytes());    }
	 
	public static byte[] compress(byte[] bArray) throws IOException {
	    ByteArrayOutputStream os = new ByteArrayOutputStream();      
	    try (DeflaterOutputStream dos = new DeflaterOutputStream(os)) {
	        dos.write(bArray);        }
	    return os.toByteArray();    }
	
	public static String decompressB64(String b64Compressed) throws IOException {
	    byte[] decompressedBArray = decompress(Base64.getDecoder().decode(b64Compressed));       
	    return new String(decompressedBArray, StandardCharsets.UTF_8);    }
	
	public static byte[] decompress(byte[] compressedTxt) throws IOException {
	    ByteArrayOutputStream os = new ByteArrayOutputStream();        
	    try (OutputStream ios = new InflaterOutputStream(os)) {
	        ios.write(compressedTxt);        }
	 
	    return os.toByteArray();    }
	
	public static String compressAndReturnB64(String text) throws IOException {
	    return new String(Base64.getEncoder().encode(compress(text)));    }
	// --- <<IS-END-SHARED>> ---
}

