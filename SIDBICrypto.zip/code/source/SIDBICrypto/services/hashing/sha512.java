package SIDBICrypto.services.hashing;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.Random;
// --- <<IS-END-IMPORTS>> ---

public final class sha512

{
	// ---( internal utility methods )---

	final static sha512 _instance = new sha512();

	static sha512 _newInstance() { return new sha512(); }

	static sha512 _cast(Object o) { return (sha512)o; }

	// ---( server methods )---




	public static final void generateHash512 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHash512)>> ---
		// @sigtype java 3.5
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
		pipelineCursor.destroy();
		
		MessageDigest digest = null;
		try {
		digest = MessageDigest.getInstance("SHA-512");
		} catch (NoSuchAlgorithmException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		byte[] encodedhash = digest.digest(inputString.getBytes(StandardCharsets.UTF_8));
		String hashHexString=bytesToHex(encodedhash);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "hashHexString", hashHexString );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static String bytesToHex(byte[] hash) {
	StringBuilder hexString = new StringBuilder(2 * hash.length);
	for (int i = 0; i < hash.length; i++) {
	    String hex = Integer.toHexString(0xff & hash[i]);
	    if(hex.length() == 1) {
	        hexString.append('0');
	    }
	    hexString.append(hex);
	}
	return hexString.toString();
		
	}
	
	// --- <<IS-BEGIN-SHARED-SOURCE-AREA>> ---
	
		
	// --- <<IS-END-SHARED>> ---
}

